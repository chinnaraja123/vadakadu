import React from 'react';
//import ReactDOM from 'react-dom';
import './App.css';
import {useState} from 'react';
import { withRouter } from 'react-router-dom';


function Register(props) { 
 
    const [input ,setInput] = useState({name:'', password:'',email:''});
    const [errorMessage ,seterrorMessage] = useState('');
    //const [successMessage ,setSuccessMessage] = useState('')
    
    
    const handleChange = (e) =>{
        setInput({...input,[e.target.name]: e.target.value });
    }

 const fromSubmitter = (e) =>{  
    // e.preventDefault();
     seterrorMessage(''); 
    
     if(!input.name) return seterrorMessage('Enter the name');
     if(!input.password) return seterrorMessage('Enter the password');
     if(!input.email) return seterrorMessage('Enter the Email');
 
   const data = new FormData();
   data.append('name',input.name)
   data.append('email',input.email)
   data.append('password',input.password)
   
   const requestOptions = {
    method: 'POST',
    headers: { 'Accept': 'application/json' },
    body: data
};

fetch('https://vadakadu.000webhostapp.com/public/api/register', requestOptions)
.then(res => {
  console.log(res);
  if (res.status === 200) {
    props.history.push('/post');
  }
    return res.json()
  
})
    .then(
      (result) => {
        //setInput(true);
        console.log(result);
        setInput(result);
      })
      

 }
  return (
    <div className="login">
      <h1 className="login-title">{props.title}</h1>
      {errorMessage && <div style={{color:"red" }}>{errorMessage}</div>}
      
        {/* <form onSubmit={fromSubmitter} >  */}

            <div className="container">
                <label for="uname"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="name" onChange={handleChange} />
                
                <label for="psw"><b>Email</b></label>
                <input type="email" placeholder="Enter email" name="email"  onChange={handleChange} />

                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password"  onChange={handleChange} />

                <button type="submit" onClick ={ ()=> fromSubmitter()}>Create</button>
               
            </div>

           
        {/* </form> */}

    </div>
  );
}

export default withRouter(Register); 
