import React from 'react';
import './App.css';
import {useState,useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import Post from './post';
const PostList =(props) => { 
  const [list, setList] = useState([]);
  const [nameList, setNameList] = useState();

  const token = localStorage.getItem('tokenName');
  const headers = {
    'Content-Type':"application/json",'Authorization': `Bearer ${token}`
   }
   
   const loginRequestOptions = {
    method: 'GET',
    headers: headers
   
  };
 
const fetchData = () =>{
const url= 'https://api.randomuser.me/';
 fetch(url)
.then((res) => {
  return res.json();
}).then((data) =>{
  //console.log(data);

  var info = data.info || {}; // {} -- info.version
  var results = data.results||[]; //[{}, {}]
  /*****
    
  results.map()

   * 
   * ***/
  setList(results);
  setNameList(info);
  console.log(results);
  console.log(info);

})
}

useEffect(()=>{
  fetchData();
},[]);

  return (
    <div className="login">
            <h1 className="login-title">{props.title}</h1>

 <table className="table ">
   <tr>
     <th>Name</th>
     <th>LastName</th>
     <th>Gender</th>

   </tr>
{list.map((obj,i) => (
<tr key={i}>
  <td>{obj.name.first}</td>
  <td>{obj.name.last}</td>
  <td>{obj.gender}</td>

</tr>
))}
</table>
    </div>
  );
}

export default PostList;
