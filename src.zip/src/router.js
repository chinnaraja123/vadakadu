import { BrowserRouter,Route,Switch } from "react-router-dom";
import React from 'react';
import ReactDOM from 'react-dom';
import Register from './register';
import Login from './login';
import Home from './home';
import Post from './post';
import PostList from './postlist';
//import {axoisAuthor,axiosReject,axiosSuccess} from './authorsitionaxios';

const Router = () =>{
 return (
     <BrowserRouter>
     <Switch>
         <Route exact path="/">
            <Login title ="Login" />
         </Route>
         <Route path="/register">
            <Register title ="Register" />
         </Route>
         <Route path="/home">
            <Home title ="home" />
         </Route>
         <Route path="/post">
            <Post title ="Post" />
         </Route>
         <Route path="/postlist">
            <PostList title ="PostList" />
         </Route>
     </Switch>
     </BrowserRouter>)
}
export default Router;