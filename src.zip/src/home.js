import React from 'react';
//import ReactDOM from 'react-dom';
import { useState } from 'react';
import './App.css';
//import Login from './login';


const Home = () =>{
 
 const [name,setName] = useState([]);
 const [outName,setOutName] = useState([{}]);
 const [errorMessage ,seterrorMessage] = useState('');


 const handleChange = (e) =>{
    setOutName((names) => ({...names,[e.target.name]:e.target.value}));
 }
 const fromSubmitter = (e) =>{
  e.preventDefault();
 //seterrorMessage(''); 
     if(!outName.name) return seterrorMessage('Enter the name');
     if(!outName.age) return seterrorMessage('Enter the age');
    setName((names) => [...names,outName]);
    setOutName({name: '',age:''});
   

 }
    return(  
       
        <div className="container" >
           {errorMessage && <div style={{color:"red" }}>{errorMessage}</div>}
            Name :<input type='text' name='name'  onChange={handleChange} value={outName.name} />
            Age :<input type='number' name='age'   onChange={handleChange}  value={outName.age} />
            <button type="submit" onClick ={fromSubmitter}>CLICK</button>
            <br/>
            <ul>
                { name.map((obj,indx) => <li key = {indx} className="text-primary" >name is {obj.name} and my age {obj.age}.</li>)}
            </ul>
            
        </div>
            
       
    )

}
export default Home;