import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import {useState} from 'react';
import { withRouter } from 'react-router-dom';


function Login(props) { 
  window.location.assign('login');
    const [input ,setInput] = useState({email:'', password:''});
    const [errorMessage ,seterrorMessage] = useState('');
    //const [successMessage ,setSuccessMessage] = useState('')
    
    const handleChange = (e) =>{
        setInput({...input,[e.target.name]: e.target.value });
    }

 const fromSubmitter = (e) =>{  
    // e.preventDefault();
     seterrorMessage(''); 
    
     if(!input.email) return seterrorMessage('Enter the email');
     if(!input.password) return seterrorMessage('Enter the password');

   const data= new FormData();
   data.append('email',input.email);
   data.append('password',input.password);
   
   const loginRequestOptions = {
    method: 'POST',
    headers: { 'Accept': 'application/json' },
    body: data
    };
    fetch('https://vadakadu.000webhostapp.com/public/api/login',loginRequestOptions)
    .then(res =>{
      console.log(res);
      if(res.status === 200){
        props.history.push('/post') ;
      }
      else{ 
        return seterrorMessage('Enter the correct value');
      }
      return res.json();
    })
    .then(res=>{
      localStorage.setItem('tokenName', (res.token));
    }).catch(err => console.log(err, "something went woring........"))
   

 }

  return (

    <div className="login">
      <h1 className="login-title">{props.title}</h1>
      {errorMessage && <div style={{color:"red" }}>{errorMessage}</div>}
      
        {/* <form  >  */}

            <div className="container">
            <label for="psw"><b>Email</b></label>
                <input type="email" placeholder="Enter email" name="email"  onChange={handleChange} />
              
                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password"  onChange={handleChange} />

                <button type="submit" onClick ={ ()=> fromSubmitter()}>Login</button>
                <div className="container" >
                    <span className="psw" onClick ={ ()=> props.history.push('/register')}>Create Account</span>
                </div>
            </div>

           
        {/* </form> */}

    </div>
  );
}

export default withRouter(Login);

