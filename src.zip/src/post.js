import React from 'react';
//import ReactDOM from 'react-dom';
import './App.css';
import {useState} from 'react';
//import Login from './login';
import { withRouter } from 'react-router-dom';

function Post(props){ 
   
    const [addPost ,setPost] = useState({ title:'', description:''});
    const [errorMessage ,seterrorMessage] = useState('');
    //const [successMessage ,setSuccessMessage] = useState('')
    
    const handleChange = (e) =>{
        setPost({...addPost,[e.target.name]: e.target.value });
    }

 const postSubmitter = (e) =>{  
    //e.preventDefault();
     seterrorMessage(''); 
    
     if(!addPost.title) return seterrorMessage('Enter the Post-title');
     if(!addPost.description) return seterrorMessage('Enter the Description');


   const token = localStorage.getItem('tokenName');

   const headers = {
    'Accept':"application/json",'Authorization': "Bearer "+token
   }
   
   const loginRequestOptions = {
    method: 'GET',
    headers: headers
    //body: data
    };
   
    fetch('https://vadakadu.000webhostapp.com/public/api/posts',loginRequestOptions)
    .then((res) => res.json()).then(data=>console.log(data))
    .catch(err => console.log(err,"error"))
    

 }
 
  return (
   

    <div className="login">``
      <h1 className="login-title">{props.title}</h1>
      {errorMessage && <div style={{color:"red" }}>{errorMessage}</div>}
      
        {/* <form  >  */}

            <div className="container">
            <label><b>Title</b></label>
                <input type="text" placeholder="Enter nmae" name="title"  onChange={handleChange} />
              
                <label ><b>Description</b></label>
                <textarea type="text" placeholder="Enter Post" name="description" rows="4" cols="53" onChange={handleChange} ></textarea>

                <button type="submit" onClick ={(e) => postSubmitter(e)}>CreatePost</button>
                
                <div className="container" >
                    <span className="psw" onClick ={ ()=> props.history.push('/postlist')}>PostList</span>
                </div>
            </div>

         
        {/* </form> */}

    </div>
  );
}

export default withRouter(Post);

