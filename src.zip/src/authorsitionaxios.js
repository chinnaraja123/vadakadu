import React from 'react';
import axios,{AxiosRequestConfig} from 'axios';
 
const axoisAuthor = () =>{
     axios.interceptors.request.use(axiosSuccess,axiosReject);


}
 const axiosSuccess = (config)=>{
    const token = localStorage.getItem('tokenName');
    if(token){
    config.headers = {
     "Authorization" :"bearer" + token,
     "cache-control" :"no-cache"
    };
 }else{
     window.location.assign('login');
 }
 return Promise.resolve(config);
}

 const axiosReject = (config)=>{
    return Promise.reject(config);

}
export {axoisAuthor,axiosReject,axiosSuccess};